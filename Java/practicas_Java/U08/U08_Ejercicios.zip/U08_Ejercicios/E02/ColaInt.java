package E02;

//Interfaz dada por Jose con funciones Cola
public interface ColaInt {

	public void vaciar();
	public boolean encolar(int i);
	public int desencolar();
	public int primero();
	public int longitud();
	
}