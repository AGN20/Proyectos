package E02;

public class ColaArrayInt implements ColaInt{
	private static final int LONGITUD_POR_DEFECTO = 10;
	private int maxLongitud;
	private int cabeza;
	private int fin;
	int[] datos;
	
	//constructor de cola con tama�o de 10
	public ColaArrayInt() { this(LONGITUD_POR_DEFECTO); }
	
	//constructor de la cola pasando su tama�o m�ximo
	public ColaArrayInt(int max) {
		maxLongitud = max + 1;
		fin = 0;
		cabeza = 1;
		datos = new int[maxLongitud];
	}
	
	//vaciar cola
	public void vaciar() { fin = 0; cabeza = 1; }
	
	//Encolar, introducimos un dato en la cola(en este caso un numero)
	public boolean encolar( int i ) {
		if((fin + 2) % maxLongitud != cabeza) {
			
			fin = (fin + 1) % maxLongitud;
			datos[fin] = i;
			
			return true;
		}else {
			return false;
		}
	}
	
	//Desencolar, nos da el primer elemento de la array, lo quita de esta y muebe la cabeza al siguiente.
	public int desencolar() {
		if(longitud() != 0) {
			int elemento = datos[cabeza];
			datos[cabeza]=0;
			cabeza = (cabeza + 1)% maxLongitud;
			return elemento;
		}else {
			return 0;
		}
	}
	
	//Nos da el priemer elemento SIN quitarlo de la array
	public int primero() {
		if(longitud() != 0) {
			return datos[cabeza];
		}else {
			return 0;
		}
	}
	
	//Nos da la longitud de la cola
	public int longitud() {
		return ((fin + maxLongitud) - cabeza + 1)% maxLongitud;
	}

	
	public String toString() {
		String resultado="";
		for(int i=cabeza;i<=fin;i++) {
			resultado = resultado +"" + datos[i] + " ";
		}
		return resultado;
	}
	
}


/*�Qu� inconviente tiene esta forma de implementar TDA's? (piensa en que
ocurrir�a si m�s adelante necesitamos una cola de doubles, luego una de Personas, luego una de
Solicitudes, luego una de Alumnos, luego una de Facturas a pagar, otra de �.) */

//El inconveniente principal esque esta manera solo contempla el uso de int (numeros enteros) 
//lo que inpide que se utilicen otros objetos