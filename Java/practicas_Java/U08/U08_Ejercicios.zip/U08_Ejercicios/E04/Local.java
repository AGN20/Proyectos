package E04;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class Local {

	private double reloj = 9.0;
	private double minuto = 1.0/60;
	private int totalClientes = 0;
	
	public PriorityQueue<Cliente> colaBuscar = new PriorityQueue();
	public PriorityQueue<Cliente> cola1 = new PriorityQueue();
	public PriorityQueue<Cliente> cola2 = new PriorityQueue();
	
	public int cuantosEntran = 0;
	
	public Cliente c = null;
	
	
	private void simular() {
		
		int[] tasaClientes = {25,40,50,65,80,42,18,21,32,40,60};
		
		
		while(reloj <= 20) {
			
			double lambda = minuto * tasaClientes[(int)reloj-9];
			cuantosEntran = getPoisson(lambda);
			
			
			for(int i=1; i<cuantosEntran; i++) {
				
				int tBuscar = (int) normal(10,5.8);
				int compra = (int) (tBuscar*Math.random()*2);
				
				c = new Cliente(
							(int)reloj,
							(int)normal(10,5.8),
							tBuscar,
							compra,
							0,
							(int)Math.ceil(2+compra/4.0),
							0
						);
				colaBuscar.add(c);
				
			}
			
			totalClientes += cuantosEntran;
			boolean quedan = false;
			
			for(Cliente e : colaBuscar) {
				e.tQueda = e.tQueda-1;
				if(e.tQueda <= 0) {
					quedan = true;
				} else {
					quedan = false;
				}
			}
			
			while(quedan) {
				colaBuscar.poll();
				c.tCola = (int) reloj;
				c.tQueda = c.tCobrar;
				if(cola1.toArray().length>cola2.toArray().length) {
					cola2.add(c);
				}else if(cola1.toArray().length<cola2.toArray().length) {
					cola1.add(c);
				}else {
					cola1.add(c);
				}
			}
			
			List<Cliente> lista1 = new ArrayList(cola1);
			
			for(Cliente q : cola1) {
				int primero = lista1.indexOf(q);
			}
			
		}	
	}
	
	public static int getPoisson(double lambda) {
		
		double l = Math.exp(-lambda);
		double p = 1.0;
		int k = 0;
		
		do{
			k++;
			p = Math.random();
		}while( p>1 );
		
		return k-1;
		
	}
	
	public static double normal(double media, double desviacion) {
		double r1 = Math.random();
		double r2 = Math.random();
		double z1 = Math.sqrt(-2*Math.log(r1))*Math.sin(2*Math.PI*r2);
		double n1 = z1*desviacion+media;
		return n1;
		
	}
	
	public static void main(String[] args) {
		
		Local l = new Local();
		
		l.simular();
		
		System.out.println("Se cierran las cajas. Pedientes en caja1: " + l.cola1.size() + " y en caja2: " + l.cola2.size() + " en local: " + l.cola1.size()+l.cola2.size() );
		System.out.println("");
		System.out.println("RESUMEN DE LA SIMULACI�N:");
		System.out.println("Local abierto de 9:00 a 20:00");
		System.out.println("Entran " + l.cuantosEntran + " Clientes");
		System.out.println("Compran " + l.c.getCompra() + " productos de media");
		System.out.println("Pasa " + l.c.getTBuscar() + " minutos buscando productos");
		System.out.println("Pasa " + l.c.getTCola() + " minutos en la cola");
		System.out.println("Pasa " + l.c.getTSale() + " minutos pagando");
		
		
	}
	
}
