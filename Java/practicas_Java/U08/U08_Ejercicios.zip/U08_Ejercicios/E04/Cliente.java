package E04;

public class Cliente {

	public double tEntra;
	public double tBuscar;
	public double tQueda;
	public double compra;
	public double tCola;
	public double tCobrar;
	public double tSale;
	
	public Cliente(int tEntra, int tBuscar, int tQueda, int compra, int tCola, int tCobrar, int tSale) {
		super();
		this.tEntra = tEntra;
		this.tBuscar = tBuscar;
		this.tQueda = tQueda;
		this.compra = compra;
		this.tCola = tCola;
		this.tCobrar = tCobrar;
		this.tSale = tSale;
	}
	
	public void setTEntrar( double d ) { tEntra = d; }
	public void setTBuscar( double d ) { tBuscar = d; }
	public void setTQueda( double d ) { tQueda = d; }
	public void setCompra( double d ) { compra = d; }
	public void setTCola( double d ) { tCola = d; }
	public void setTCobrar( double d ) { tCobrar = d; }
	public void setTSale( double d ) { tSale = d; }
	
	public double getTEntrar() { return tEntra;}
	public double getTBuscar() { return tBuscar;}
	public double getTQueda() { return tQueda;}
	public double getCompra() { return compra;}
	public double getTCola() { return tCola;}
	public double getTCobrar() { return tCobrar;}
	public double getTSale() { return tSale;}
}
