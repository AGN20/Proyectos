 package E01;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class U08E01A {
	public static void main(String[] args) {
		String s1;
		String s2;
		List<Palabra> lista = new ArrayList<>();
		long tiempo = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader("./src/E01/texto/quijote_cervantes.txt"));
			Scanner sc = new Scanner(br);
			sc.useDelimiter("[., \n:;\t]");
			int contador = 0;
			tiempo = System.currentTimeMillis();
			while(sc.hasNext()) {
				
				String palabra = sc.next();
				Palabra p = new Palabra(palabra);
				boolean esta = false;
				
				for(Palabra pa : lista) {
					int compara = p.compareTo(pa);
					if(p.compareTo(pa)==1) {
						long cont = pa.getContador();
						pa.setContador(cont+1);
						long conta = pa.getContador();
						esta = true;
					}else {
						esta = false;
					}
				}
				
				if(esta == false) {
					lista.add(p);
				}
				
			}
			tiempo = System.currentTimeMillis()-tiempo;
		} catch ( IOException e) {
			e.printStackTrace();
		}	
		
		
		
		System.out.println("He contabilizado: " + lista.size() + " palabras.");
		System.out.println("He tardado: " + (tiempo/1000)/60 + " minutos.");
		
		String pMayor = null;
		long cMayor = 0;
		for(Palabra e : lista) {
			if(e.getPalabra().length()>5 && e.getContador()>=cMayor) {
				cMayor = e.getContador();
				pMayor = e.getPalabra();
			}
		}
		
		System.out.println("La palabra de m�s de cinco letras que m�s aparece es: " + pMayor + ", y aparece: " + cMayor + " veces.");
		
	}
}

class Palabra implements Comparable{
	private String palabra;
	private long contador;
	
	public Palabra(String palabra) {
		this.palabra = palabra;
		contador = 1;
		
	}

	public String getPalabra() {
		return palabra;
	}

	public void setPalabra(String palabra) {
		this.palabra = palabra;
	}

	public long getContador() {
		return contador;
	}

	public void setContador(long l) {
		this.contador = l;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		long result = 1;
		result = prime * result + contador;
		result = prime * result + ((palabra == null) ? 0 : palabra.hashCode());
		return (int) result;
	}

	@Override
	public boolean equals(Object obj) {
		try {
			Palabra otro = (Palabra)obj;
			if(palabra.equals(otro.palabra)&&contador == otro.contador) {
				return true;
			}
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (obj instanceof String) {
				return obj.equals(palabra);
			}
			if (obj.toString().equals(palabra)) {
				return true;
			}
			if (getClass() != obj.getClass())
				return false;
			Palabra other = (Palabra) obj;
			if (contador != other.contador)
				return false;
			if (palabra == null) {
				if (other.palabra != null)
					return false;
			} else if (!palabra.equals(other.palabra))
				return false;
			return true;
			
		} catch (Exception e) {
			return false;
		}
	 
	}

	@Override
	public int compareTo(Object o) {
		
		Palabra otro = (Palabra)o;
		String p = otro.getPalabra();
		Long c = otro.getContador();
		if(this.palabra.equals(p) && o instanceof Palabra) {
			return 1;
		} else { return -1; }
		
	}
	
	
	
}
