package E01;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.StringTokenizer;

public class U08E01B {
	public static void main(String[] args) {
		String s1;
		String s2;
		List<Palabra> lista = new ArrayList<>();
		long tiempo = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader("./src/E01/texto/quijote_cervantes.txt"));
			Scanner sc = new Scanner(br);
			sc.useDelimiter("[., \n:;\t]");
			int contador = 0;
			tiempo = System.currentTimeMillis();
			 HashMap<String, Long> mapa = new HashMap<>();
	            while (sc.hasNext()){
	                String aux = sc.next().toUpperCase();
	                
	                if(mapa.get(aux)==null){
	                    if(!"".equals(aux)){
	                    mapa.put(aux, 1L);
	                    }
	                }else{
	                    mapa.put(aux, mapa.get(aux)+1);
	                }
	            }
	            
	            long maxCont=0L;
	            String maxString = "";
	            long contadorPalabras = 0L;
	            for ( Entry<String, Long> entry : mapa.entrySet()) {
	                contadorPalabras+=entry.getValue();
	            if(entry.getValue()>maxCont && entry.getKey().length()>5){
	            	maxCont = entry.getValue();
	            	maxString = entry.getKey();
	            }
	    }
	        
	            
	            tiempo = (System.currentTimeMillis()-tiempo)/1000;
	            System.out.println("Total de palabras: "+contadorPalabras);
	            System.out.println("Tiempo utilizado: "+tiempo+" segundos.");
	            System.out.println("La palabra m�s usada es "+maxString+" con "+maxCont+" veces." );
	           
	        } catch (FileNotFoundException ex) {}
		}
	}