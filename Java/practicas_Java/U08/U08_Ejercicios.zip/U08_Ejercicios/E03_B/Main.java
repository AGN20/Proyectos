package E03_B;

public class Main {

	public static void main(String[] args) {
		
		ColaArrayObj cola1 = new ColaArrayObj(20);
		cola1.encolar(1);
		cola1.encolar(2);
		cola1.encolar(3);
		cola1.encolar(4);
		
		System.out.println(cola1);
		cola1.desencolar();
		cola1.encolar(5);
		System.out.println(cola1);
		
		ColaArrayObj cola2 = new ColaArrayObj(20);
		cola2.encolar("Camino");
		cola2.encolar("Ciudad");
		cola2.encolar("Puerto");
		cola2.encolar("Monta�a");
		
		System.out.println(cola2);
		cola2.desencolar();
		cola2.encolar("Pueblo");
		System.out.println(cola2);
		
		//Iniciamos las personas
		Personas p1 = new Personas("Mario Genio", 25);
		Personas p2 = new Personas("Sara Garcia", 19);
		Personas p3 = new Personas("Ruben Cerrillo", 20);
		Personas p4 = new Personas("Guillermo Fuentes", 19);
		Personas p5 = new Personas("Danile Barroso", 23);
		
		ColaArrayObj cola3 = new ColaArrayObj(20);
		cola3.encolar(p1.getNombre());
		cola3.encolar(p2.getNombre());
		cola3.encolar(p3.getNombre());
		cola3.encolar(p4.getNombre());
		
		System.out.println(cola3);
		cola3.desencolar();
		cola3.encolar(p5.getNombre());
		System.out.println(cola3);
		
	}
	
	
	
}
