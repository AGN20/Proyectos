package E07;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class U08E07 {

public static void main(String [] args) {
		
		//Padamos los textos
		String texto1 = "Adherirse al sistema arbitral es voluntario e incluso pueden solicitar su adhesi�n dejando al margen ciertos conflictos. Aunque sin estar inscrita, podr�a aceptar este mecanismo en alg�n caso";
		
		String texto2 = "Unirse es voluntario e incluso pueden solicitar su adhesi�n dejando al margen ciertos conflictos. Aunque sin estar inscrita podr�a aceptar este mecanismo en alg�n caso";
		
		String texto3 = "Aunque sin estar inscrita podr�a aceptar este mecanismo en alg�n caso pero adherirse al sistema arbitral es voluntario e incluso pueden solicitar su adhesi�n dejando al margen ciertos conflictos";
		 
		//Calculamos el coeficiente Levenshtein
		double d1 = coeficienteLevenshtein(texto1, texto2)/Math.max(texto1.length(), texto2.length()); //diferencia entre T1 y T2
		double d2 = coeficienteLevenshtein(texto1, texto3)/Math.max(texto1.length(), texto3.length()); //diferencia entre T1 y T3
		double d3 = coeficienteLevenshtein(texto2, texto3)/Math.max(texto2.length(), texto3.length()); //diferencia entre T2 y T3	
		
		//calculamos cuanta similitud tiene con el coeficiente Levenshtein
		double r1 = 1 - d1; //similitud entre T1 y T2
		double r2 = 1 - d2; //similitud entre T1 y T3
		double r3 = 1 - d3; //similitud entre T2 y T3
		
		//Calculamos el coeficiente Jaccard
		double rj1 = coeficienteJaccard(texto1, texto2); //diferencia entre T1 y T2
		double rj2 = coeficienteJaccard(texto1, texto3); //diferencia entre T1 y T3
		double rj3 = coeficienteJaccard(texto2, texto3); //diferencia entre T2 y T3
		
		//Imprimimos por pantalla
		System.out.println("Texto 1 y Texto 2:");
		System.out.println("	Similitud Lexica (Levenshtein): " + r1);
		System.out.println("	Similitud Semantica (Jaccard): " + rj1);
		System.out.println("	Media: " + ((r1+rj1)/2));
		
		System.out.println("Texto 1 y Texto 3:");
		System.out.println("	Similitud Lexica (Levenshtein): " + r2);
		System.out.println("	Similitud Semantica (Jaccard): " + rj2);
		System.out.println("	Media: " + ((r2+rj2)/2));
		
		System.out.println("Texto 2 y Texto 3:");
		System.out.println("	Similitud Lexica (Levenshtein): " + r3);
		System.out.println("	Similitud Semantica (Jaccard): " + rj3);
		System.out.println("	Media: " + ((r3+rj3)/2));
		
	}
	
	//metodo del coeficiente Levenshtein
	public static double coeficienteLevenshtein(String texto1, String texto2) {
		
		String[] t1 = texto1.toLowerCase().split("[ \\n\\t\\r.,;:()]");
		String[] t2 = texto2.toLowerCase().split("[ \\n\\t\\r.,;:()]");
		
		int[][] d = new int[t1.length+1][t2.length+1];
		
		int i, j;
		int coste = 0;
		
		for (i=0; i<=t1.length;i++) {d[i][0] = i;}
		for (j=0; j<=t2.length;j++) {d[0][j] = j;}
		for (i=1; i<=t1.length;i++) {
			for(j=1; j<=t2.length;j++) {
				if (t1[i-1].equals(t2[j-1])) {
					coste = 0;
				}else { coste = 1;}//fin si
				d[i][j] = Math.min(
						Math.min(
								d[i-1][j] + 1, 
								d[i][j-1] + 1),
								d[i-1][j-1] + coste
								);
			}//fin
			
		}
		return d[t1.length][t2.length]/Math.max(1.0,Math.abs(t1.length-t2.length));
	}
	
	//metodo del coeficiente Jaccard
	public static double coeficienteJaccard(String texto1, String texto2) {
		
		String[] t1 = texto1.toLowerCase().split("[ \\n\\t\\r.,;:()]");
		String[] t2 = texto2.toLowerCase().split("[ \\n\\t\\r.,;:()]");
	
		//creaci�n de Colecciones
		Set<String> conjunto1 = new HashSet<>();
		conjunto1.addAll(Arrays.asList(t1));
		
		Set<String> conjunto2 = new HashSet<>();
		conjunto2.addAll(Arrays.asList(t2));
		
		//N� de palabras comunes en los dos textos
		Set<String> comunes = new HashSet<>(conjunto1);
		comunes.retainAll(conjunto2);
		
		//N� de palabras que est�n en t1 y no en t2
		Set<String> t1T2 = new HashSet<>(conjunto1);
		t1T2.removeAll(conjunto2);
		
		//N� de palabras que est�n en t2 y no en t1
		Set<String> t2T1 = new HashSet<>(conjunto2);
		t2T1.removeAll(conjunto1);
		
		double a = comunes.size();
		double b = t1T2.size();
		double c = t2T1.size();
		
		//Calcular el resultado
		double resultado = a/(a+b+c);
		
		return resultado;
		
	}
	
}
