package E05;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class U08E05 {

static ArbolB<NodoS> listaP;
	
	
	public static void main(String[] args) {
		String s1;
		String s2;
		long tiempo = 0;
		String palabra1 = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader("./src/E05/texto/quijote_cervantes.txt"));
			Scanner sc = new Scanner(br);
			sc.useDelimiter("[., \n:;\t]");
			int contador = 0;
			tiempo = System.currentTimeMillis();
			while(sc.hasNext()) {
				
				String palabra = sc.next();
				
				if(contador == 0) {
					palabra1 = palabra;
					NodoS n1 = new NodoS(palabra1);
					listaP = new ArbolB(n1,n1.getS().length());
				}else {
					NodoS n = new NodoS(palabra);
					ArbolB nuevo = new ArbolB(n,n.getS().length());
					listaP.instertarNodo(nuevo);
				}
				contador++;
			}
			tiempo = System.currentTimeMillis()-tiempo;
			listaP.buscarX(10);
		} catch ( IOException e) {
			e.printStackTrace();
		}	
	
		System.out.print(palabra1);
	}
	
}
