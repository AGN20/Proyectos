package E05;

public class NodoS implements Comparable<NodoS>{
	
	private String s;
	private int i;
	
	public NodoS(String s) {
		this.s = s;
		i = 1;
	}
	
	@Override
	public int compareTo(NodoS o) {
		NodoS otro = (NodoS)o;
		String p = otro.getS();
		if(this.getS().equals(p) && o instanceof NodoS) {
			return 1;
		} else { return -1; }
	}

	public String getS() {return s;}
	public void setS(String s) {this.s = s;}
	public int getI() {return i;}
	public void setI(int i) {this.i = i;}
	
}
