package E05;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

public class ArbolB<E> {
	protected ArbolB<E> padre;	//Nodo padre
	protected int ne;			//Cantidad de nodos
	protected E e;				//Elemento que almacena
	protected ArbolB<E> izq;	//Puntero al arbol Hijo izquierdo
	protected ArbolB<E> der;	//Puntero al arbol Hijo derecho
	protected int valor;

	//Constructores
	public ArbolB(E k, ArbolB<E> i, ArbolB<E> d, int valor) {
		this.e = k;
		this.padre = null; //es la ra�z del �rbol
		this.izq = i;
		this.der = d;
		this.ne = 1;
		this.valor = valor;
	}
	
	public ArbolB(E k, int valor) {
		this.e = k;
		this.padre = null; //es la ra�z del �rbol
		this.izq = null;
		this.der = null;
		this.ne = 1;
		this.valor = valor;
	}
	
	public ArbolB() {this(null,null,null,0);}
	public ArbolB(E k) {this(k, null, null,0);}
	
	public E getE() { return e; }
	public void setE(E k) {e = k;}
	
	public ArbolB<E> getIzq()  { return izq; }
	public ArbolB<E> getDer()  { return der; }
	
	// Conectar un �rbol como hijo izquierdo
	
	public void setIzq(ArbolB<E> i) {
		ArbolB<E> nodo;
		int sePierden = (izq == null) ? 0 : izq.ne; //nodos se van
		izq = i; //Se conecta el �rbol a la nueva rama
		if(i != null) {
			sePierden -= i.ne;
			i.padre = this;
		}
		//Actualizar la cantidad de nodos subiendo hasta la ra�z
		ne -= sePierden;
		nodo = this.padre;
		while(nodo!=null) {
			ne -= sePierden;
			nodo = nodo.padre;
		}
	}
	
	//Conectra un �rbol como hijo derecho
	
	public void setDer(ArbolB<E> d) {
		ArbolB<E> nodo;
		int sePierden = (der == null) ? 0 : der.ne; //nodos se van
		der = d; //Se conecta el �rbol a la nueva rama
		if(d != null) {
			sePierden -= d.ne;
			d.padre = this;
		}
		//Actualizar la cantidad de nodos subiendo hasta la ra�z
		ne -= sePierden;
		nodo = this.padre;
		while(nodo!=null) {
			ne -= sePierden;
			nodo = nodo.padre;
		}
	}
	
	public int getSize() {return ne;}
	
	public void vaciar() {
		if(padre!=null)padre.ne -= ne-1;
		ne = 0;
		e = null;
		izq = null;
		der = null;
	}
	
	//Desconecta el arbol
	public void desconectar() {
		if(padre!=null) {
			//Desconectar al �rbol
			if(padre.izq == this) padre.setIzq(null);
			else padre.setDer(null);
			padre = null; //Desconectar el nodo
		}
	}

	public ArbolB<E> getPadre() {return padre;}
	public void setPadre(ArbolB<E> padre) {this.padre = padre;}
	
	public int getV() {return valor;}
	public void setV(int v) {this.valor = v;}

	public void instertarNodo(ArbolB n) {
		generar(n,n.getPadre());
	}
	
	public void generar(ArbolB n, ArbolB padre) {
		if(padre==null) {
			this.setPadre(n);
		}else {
			if(n.valor<=padre.valor) {
				if(padre.getIzq()==null) {
					padre.setIzq(n);
				}else {
					generar(n,padre.getIzq());
				}
			} else {
				if(padre.getDer()==null) {
					padre.setDer(n);
				}else {
					generar(n,padre.getDer());
				}
			}
		}
	}
	
	public void buscarX(int valor) {
		ArbolBPreorden<ArbolB<NodoS>> p = new ArbolBPreorden(padre);
		if(!p.hasNext())System.out.println("Ninguno");
		else {
			while(p.hasNext()) {
				if(p.next().getV()<valor) {
					buscarX(valor+1);
				}else if(p.next().getV()==valor){
					System.out.println(p.next().getE().toString());
				}
			}	
		}
	}
	
}

class ArbolBPreorden<E> implements Iterator<ArbolB<E>>{
	Stack<ArbolB<E>> pila;
	
	//Constructor
	public ArbolBPreorden(ArbolB<E> raiz) {
		if(raiz == null) return;
		pila = new Stack<ArbolB<E>>();
		pila.push(raiz);
	}
	
	public boolean hasNext() {
		return !pila.empty();
	}
	
	public ArbolB<E> next(){
		if(!hasNext()) throw new NoSuchElementException();
		ArbolB<E> next = pila.pop();
		if(next.getDer()!=null) {
			pila.push(next.getDer());
		}
		if(next.getIzq()!=null) {
			pila.push(next.getIzq());
		}
		return next;
	}
}
