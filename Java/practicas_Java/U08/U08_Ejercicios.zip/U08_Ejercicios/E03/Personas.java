package E03;

public class Personas {

	private String nombre;
	private int edad;
	
	public Personas (String n, int e ) {
		
		nombre = n;
		edad = e;
		
	}
	
	public String getNombre() { return nombre; }
	public int getEdad() { return edad; }
	
	public void setNombre( String n ) { nombre = n; }
	public void setEdad( int e ) { edad = e; }
	
}
