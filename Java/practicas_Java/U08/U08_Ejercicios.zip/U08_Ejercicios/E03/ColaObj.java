package E03;

//Interfaz dada por Jose con funciones Cola
public interface ColaObj {

	public void vaciar();
	public boolean encolar(Object i);
	public Object desencolar();
	public Object primero();
	public int longitud();
	
}