package com.adgonu.myapplication.model.model

//Creamos el objeto de los detalles( en firebases se llama pasos )
data class Details(
    var numero: Int = 0,
    var nombre: String = "",
    var descripcion: String = "",
    var completado: Boolean = false
)
