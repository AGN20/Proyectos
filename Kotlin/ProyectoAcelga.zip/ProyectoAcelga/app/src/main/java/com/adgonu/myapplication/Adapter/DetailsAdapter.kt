package com.adgonu.myapplication.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adgonu.myapplication.R
import com.adgonu.myapplication.model.model.Details
import com.adgonu.myapplication.viewmodel.DetailsViewHolder

class DetailsAdapter(val detailsList: List<Details>): RecyclerView.Adapter<DetailsViewHolder>() {

    //Funcion que nos mete el layaut item_details en el main
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailsViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return DetailsViewHolder(layoutInflater.inflate(R.layout.item_details, parent, false))
    }

    //Variable con el tamaño de la lista detailsList
    override fun getItemCount(): Int = detailsList.size

    //Funcion que indica el elemento details de dentro del detailsList que se va a mostrar
    override fun onBindViewHolder(holder: DetailsViewHolder, position: Int){
        val item = detailsList[position]
        holder.bind(item)
    }


}