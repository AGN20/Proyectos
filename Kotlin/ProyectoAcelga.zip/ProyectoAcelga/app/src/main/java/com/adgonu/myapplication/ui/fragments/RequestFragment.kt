package com.adgonu.myapplication.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adgonu.myapplication.Adapter.DetailsAdapter
import com.adgonu.myapplication.R
import com.adgonu.myapplication.model.model.Details
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

class RequestFragment : Fragment() {

    //Base de datos de Firebase
    val db = FirebaseFirestore.getInstance()

    //ReciclerView sin Iniciar
    lateinit var rvDetails: RecyclerView
    lateinit var detailsList: ArrayList<Details>
    lateinit var adapter: DetailsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_request, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //Lista de Monstruos
        detailsList = arrayListOf<Details>()

        rvDetails = view.findViewById(R.id.rvDetails)
        rvDetails.setHasFixedSize(true)
        rvDetails.visibility = View.VISIBLE
        rvDetails.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

        setup(view)

        //Introducimos el adapteador con su contexto y la lista de monstruos
        adapter = DetailsAdapter(detailsList)

        rvDetails.adapter = adapter
    }



    private fun setup(view: View) {

        var txRequest: TextView = view.findViewById(R.id.txRequest)

        var capital: String? = null
        var socios: String? = null

        if (arguments != null){
            capital = requireArguments().getString("capital")
            socios = requireArguments().getString("socios")
        }

        buscarDocumento(txRequest, capital, socios)

        Log.d("TAG", "ARRAY = " + detailsList)

    }


    /** Buscamos la forma juridica más adecuada dependiendo de nuestro capital y numero de socios **/
    private fun buscarDocumento(txRequest: TextView, capital: String?, socios: String?){

        //Consulta
        val docuFJ = db.collection("formasJuridicas")
            .whereEqualTo("numSocios", socios!!.toInt()) //NumSocios igual a socios indicados
            .whereLessThanOrEqualTo("capital", capital!!.toInt())//capital menos o igual al capital indicado
            .orderBy("capital", Query.Direction.DESCENDING)//Orden descendente, para que escoja el mas cercano
            .get()
            .addOnSuccessListener { result -> //Recuperamos el nombre, y lo agregamos al text view
                for (document in result){
                    var doc = document.get("nombre").toString()
                    Log.d("TAG", "Nombre = " + doc)
                    txRequest.text = doc

                    val docuFJdetails = db.collection("pasos")
                        .whereEqualTo("nombreFJ", doc) //NumSocios igual a socios indicados
                        .orderBy("numero", Query.Direction.ASCENDING)
                        .get()
                        .addOnSuccessListener { result -> //Recuperamos el nombre, y lo agregamos al text view

                            for (doc in result){
                                val detail: Details = doc.toObject(Details::class.java)
                                Log.d("TAG", "" + detail)
                                detailsList.add(detail)
                            }

                            rvDetails.adapter = DetailsAdapter(detailsList)

                        }
                        .addOnFailureListener{exception ->
                            Log.d("TAG", "error al obtener los datos $exception")
                        }

                    //Salimos del for, para coger solo el mas cercano
                    break
                }
            }
            .addOnFailureListener{exception ->
                Log.d("TAG", "error al obtener los datos $exception")
            }
    }

}
