package com.adgonu.ejercicioreciclerview.interfaces

import com.adgonu.ejercicioreciclerview.modelo.Superhero

interface OnItemClick {
    fun onItemClick(hero:Superhero)
}