package com.adgonu.artnutria.data.Interface

import com.adgonu.artnutria.data.modelo.Usuario

interface OnItemClickListenerUsuario {
    fun onItemClick(user: Usuario)
}