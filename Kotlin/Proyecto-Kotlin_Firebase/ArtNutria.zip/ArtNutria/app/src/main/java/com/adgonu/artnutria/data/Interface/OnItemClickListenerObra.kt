package com.adgonu.artnutria.data.Interface

import com.adgonu.artnutria.data.modelo.Obra

interface OnItemClickListenerObra {
    fun onItemClick(obra: Obra)
}