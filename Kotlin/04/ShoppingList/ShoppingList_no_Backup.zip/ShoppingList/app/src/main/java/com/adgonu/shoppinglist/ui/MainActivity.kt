package com.adgonu.shoppinglist.ui

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.RoomDatabase
import com.adgonu.shoppinglist.R
import com.adgonu.shoppinglist.adapters.ProductoAdapter
import com.adgonu.shoppinglist.database.ProductoDatabase
import com.adgonu.shoppinglist.database.entities.ProductoEntity
import com.adgonu.shoppinglist.databinding.ActivityMainBinding
import com.adgonu.shoppinglist.databinding.FragmentHomeBinding
import com.adgonu.shoppinglist.viewmodel.ProductoViewModel
import java.io.File
import android.content.SharedPreferences
import android.os.Environment
import com.adgonu.shoppinglist.ui.fragmnets.HomeFragment
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.lang.Exception


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var productViewModel:ProductoViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ActivityMainBinding.inflate(layoutInflater).also { binding = it }.root)

        productViewModel = ViewModelProvider(this)[ProductoViewModel::class.java]

        // NAVIGATION
        setSupportActionBar(binding.toolbar)

        val navHosFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHosFragment.navController

        val appBarConfiguration = AppBarConfiguration(setOf(
            R.id.options1,
            R.id.options2,
            R.id.options3,
            R.id.options4,
        )
        )

        NavigationUI.setupWithNavController(binding.toolbar, navController, appBarConfiguration)

    }

    // NAVIGATION
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu);
        return true;
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val fileRead = "producto-db"
        val fileSave = "producto-db-save"


        return when (item.itemId){
            R.id.options2 -> {

                productViewModel.deleteAll()
                showMessage("Base de datos eliminada")

                navController?.navigate(R.id.homeFragment)

                true
            }
            R.id.options3 -> {

                saveFile(fileSave, fileRead)

                showMessage("Backup Creado")
                true
            }
            R.id.options4 -> {

                readFile(fileRead)

                showMessage("Backup restaurado")
                true
            }

            else -> super.onOptionsItemSelected(item)
        }

    }

    // Funciona, pero si no lees antes los datos no puedes escribirlos
    fun saveFile (file: String, fileSave: String){
        /* /data/data/com.adgonu.shoppinglist/databases/producto-db */

        //var fileRead = readFile(file).toString()

        this.openFileOutput(fileSave, Context.MODE_PRIVATE).use {
            it.write(file.toByteArray())
        }

    }

    // NO FUNCIONA
    fun readFile (file: String){
        this.openFileInput(file).bufferedReader().useLines { lines ->
            lines.fold("") { some, text ->
                "$some/n$text"
            }
        }
    }


    private fun showMessage(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}