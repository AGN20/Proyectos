package com.adgonu.broadcastreceiver1.notification

const val PENDING_REQUEST = 10
const val CHANNEL_ID = "Notification_ID"
const val CHANNEL_NAME = "My Notifications"
const val NOTIFICATION_ID = 10